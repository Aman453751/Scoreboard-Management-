---
name: OmniScore Collegiate Sports System
colors:
  surface: '#0e131f'
  surface-dim: '#0e131f'
  surface-bright: '#343947'
  surface-container-lowest: '#090e1a'
  surface-container-low: '#161b28'
  surface-container: '#1a1f2c'
  surface-container-high: '#252a37'
  surface-container-highest: '#303542'
  on-surface: '#dee2f4'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dee2f4'
  inverse-on-surface: '#2b303e'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0e131f'
  on-background: '#dee2f4'
  surface-variant: '#303542'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  score-display:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
  label-md:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.05em
  stat-mono:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a high-performance, dark sports-technology interface built for high-density live scorekeeping, athletic department administration, and high-stakes tournament operations. The aesthetic balances analytical rigor with sports broadcast dynamism—borrowing the clean spatial discipline of professional athletic dashboards (ESPN, Sofascore) and pairing it with real-time telemetric clarity.

### Personality & Values
- **Operational Precision**: Every pixel, numerical split, and match metric serves immediate situational awareness. No purely decorative gradients or extraneous glass blurs.
- **Atmospheric Focus**: Deep navy surfaces reduce visual fatigue during evening games and extended desk sessions while providing maximum contrast for live status badges, period clocks, and team color indicators.
- **Institutional Reliability**: Built to evoke authority, structure, and enterprise-grade data throughput suitable for campus athletic directors, conference referees, and live tournament desks.

### Style Directives
- **Architecture**: Utilitarian Dark Mode SaaS with structured card containers, low-contrast separation strokes, and compact telemetry hubs.
- **Hierarchy**: Data-dense grids where typography scale, weight variance, and deliberate tabular alignment define priority over heavy shadow drop-offs.

## Colors

The palette operates on a structured dark hierarchy rooted in collegiate navy tones, engineered to maximize visibility of dynamic scores and status indicators.

### Surface Tiers
- **Canvas Base (`#080D19`)**: The primary viewport foundation, ensuring absolute ink depth without the harsh dead-black contrast of `#000000`.
- **Card Surface Tier 1 (`#101A2D`)**: Standard background for tournament brackets, match modules, team rows, and analytical tables.
- **Card Surface Tier 2 (`#15233D`)**: Secondary raised containers, active list rows, hover states, and input field backgrounds.
- **Border Stroke (`#1E2D4A`)**: Low-contrast architectural borders isolating tabular data without visual obstruction.

### Signal & Accent Colors
- **Primary Blue (`#3B82F6`)**: Primary actionable targets, navigation active anchors, primary CTA buttons, and brand badges.
- **Telemetry Cyan (`#06B6D4`)**: Live sync badges, socket connectivity indicators, match period milestones, and supplementary analytical metrics.
- **Live State Red (`#EF4444`)**: Exclusive to active game broadcasts, live flashing indicators, critical play clock alerts, and penalty notices.
- **Success Green (`#10B981`)**: Finalized victory states, verified scoring validations, active tournament nodes, and positive point differentials.

## Typography

The type system relies on `Inter` across all structural layers to maximize legibility in high-density data sheets, live scores, and multi-team tournament brackets.

### Numerical Legibility
- Tabular lining numbers (`tnum`, `zero`) must be applied globally to score displays, play clocks, and tabular statistics grids to prevent jitter during live WebSocket updates.
- Match scores must prioritize immediate peripheral readability: score figures use `score-display` (`1.75rem / 700`) to anchor the card module visually.

### Hierarchy & Treatment
- Display headlines use tight negative tracking (`-0.025em`) to conserve horizontal space for dense dashboard viewports.
- All category indicators, tournament formats, and sport pill tags leverage `label-sm` with full uppercase transformation and expanded letter spacing (`+0.05em`) for instantaneous classification.

## Layout & Spacing

The layout operates on a flexible, high-density 12-column grid designed for simultaneous multi-fixture monitoring and score entry workflows.

### Grid & Density Rules
- **Breakpoints**: 
  - Desktop (`≥1280px`): 12-column layout with `gutter-lg` (1.5rem) and bounded container width (`1440px`). Scoreboard consoles span 3-column or 4-column cards.
  - Tablet (`768px - 1279px`): 8-column layout with `gutter` (1rem); cards reflow into 2-column matrices.
  - Mobile (`<768px`): 4-column layout; modules collapse into full-width stacked vertical cards with edge padding restricted to `space-md` (0.75rem).
- **Internal Density**: Compact internal container padding ensures real-time scoreboards show period counters, foul summaries, and team branding above the standard vertical fold. Match rows maintain a fixed minimum height of `48px` to guarantee confident touch targets during sideline scoring operations.

## Elevation & Depth

Visual depth is achieved through crisp boundary delineation and tonal stepped backgrounds rather than soft, diffused blurs.

### Tonal Stratification
- **Level 0 (Floor)**: `#080D19` canvas for base page backdrop.
- **Level 1 (Card Matrix)**: `#101A2D` with an explicit `1px solid #1E2D4A` stroke for match scoreboards, metric panels, and sidebars.
- **Level 2 (Active/Hovered Containers)**: `#15233D` surface fill with `#3B82F6` accent border emphasis during selected or live-scoring states.
- **Level 3 (Overlays & Drawers)**: `#0F172A` with standard perimeter border `#1E2D4A` and restrained shadow `0 10px 25px -5px rgba(0, 0, 0, 0.5)`.

### Outline & Glow Philosophy
No generic dropshadows on static widgets. Live-status signals receive subtle pinpoint radial glow pulses (`rgba(239, 68, 68, 0.4)` for live alerts, `rgba(16, 185, 129, 0.4)` for real-time WebSocket sync), ensuring attention remains strictly centered on dynamic game state transitions.

## Shapes

The design system employs a soft, disciplined corner geometry (`roundedness: 1`), providing an industrial, sports-software look that maximizes screen real estate.

### Corner Radius System
- **Base Elements (`rounded`, 0.25rem / 4px)**: Default for input fields, data table cells, category chips, sport badges, and internal team avatar icons.
- **Containers & Cards (`rounded-lg`, 0.5rem / 8px)**: Match card modules, tournament bracket cards, modal panels, and stats tables.
- **Feature Badges & Overlays (`rounded-xl`, 0.75rem / 12px)**: Floating utility docks and primary score header wrappers.
- **Pill Exceptions (`rounded-full`)**: Solely reserved for circular status pings, numeric badge counts, and live broadcast indicators.

## Components

### Buttons
- **Primary Button**: Solid `#3B82F6` fill, text `#FFFFFF`, font weight `600`, radius `4px`. Hover state: `#2563EB`. Active state: `#1D4ED8`. Focus: `2px` ring `#06B6D4` offset by `2px` `#080D19`.
- **Secondary Button**: Surface `#101A2D`, border `1px solid #1E2D4A`, text `#FFFFFF`. Hover: border `#3B82F6`, background `#15233D`.
- **Live Sync / Status Button**: Surface `rgba(16, 185, 129, 0.1)`, border `1px solid rgba(16, 185, 129, 0.3)`, text `#10B981` accompanied by a pulsing `6px` green circle indicator.

### Match & Scoreboard Cards
- **Container**: Background `#101A2D`, border `1px solid #1E2D4A`, corner radius `8px`, padding `1.25rem`.
- **Header**: Sport pill (`#080D19` fill, text `#94A3B8`, uppercase `label-sm`), tournament subtitle, and an inline `LIVE` pill (`#EF4444` background or border tint).
- **Match Content**: Vertical team list where each team has an avatar/crest, institution title (`body-md`, `#FFFFFF`), and high-contrast score readout (`score-display`, `#FFFFFF`). The leading team's score maintains full contrast; trailing teams dim to `#94A3B8`.
- **Footer**: Divided by `1px solid #1E2D4A`, displaying current quarter/inning in `body-sm` (`#94A3B8`) and action links ("Scoreboard Console →") in `#3B82F6`.

### Chips & Sport Tags
- Height: `22px`. Padding: `0 6px`. Radius: `4px`.
- Inactive: Background `#15233D`, border `1px solid #1E2D4A`, text `#94A3B8`.
- Active/Highlight: Background `rgba(59, 130, 246, 0.15)`, border `1px solid #3B82F6`, text `#60A5FA`.

### Data Tables & Stats Grids
- **Header Row**: Background `#080D19`, height `36px`, text `#64748B`, uppercase `label-sm`, letter spacing `0.05em`.
- **Data Rows**: Height `44px`, border bottom `1px solid #1E2D4A`. Hover: background `#15233D`.
- **Numeric Cells**: Right-aligned, formatted with `stat-mono` font settings.

### Inputs & Selection Controls
- **Text Inputs**: Surface `#0B1220`, border `1px solid #1E2D4A`, text `#FFFFFF`, radius `4px`, padding `0.5rem 0.75rem`. Focus: border `#3B82F6`, no ambient glow.
- **Checkboxes & Radios**: `16px x 16px`, background `#0B1220`, border `1px solid #1E2D4A`. Checked state: background `#3B82F6`, border `#3B82F6`.